#include<bits/stdc++.h>
using namespace std;
int main(){
	vector<int > v;
	char a[100000],b[100000];
	scanf("%s%s",a,b);
	int c[100000],d[100000];
	memset(c,0,sizeof(c));
	memset(d,0,sizeof(d));
	int l1,l2,i,j,x=0;
	l1=strlen(a);
	l2=strlen(b);
	j=0;
	for(i=l1-1;i>=0;i--)
		c[j++]=a[i]-48;
	j=0;
	for(i=l2-1; i>=0; i--)
		d[j++]=b[i]-48;
	if(l2>l1)
		l1=l2;
	for(i=0; i<l1; i++){
		x=x+c[i]+d[i];
		v.push_back(x%10);
		x/=10;
	}
	if(x!=0)
		v.push_back(x);
	x=v.size();
	for(i=x-1;i>=0;i--){
		printf("%d", v[i]);
	}
	printf("\n");
	return 0;
}